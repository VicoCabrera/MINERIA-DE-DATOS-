from deepface import DeepFace
import cv2
import numpy as np
import tkinter as tk
from tkinter import Label, Frame
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading

# Configuración de la ventana principal
root = tk.Tk()
root.title("Detector de Emociones")
root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")  # Pantalla completa

# Crear un marco para el título y subtítulo
frame_header = Frame(root)
frame_header.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=5, pady=5)

# Título
title_label = Label(frame_header, text="Detección de Emociones", font=("Helvetica", 30, "bold"), bg='lightblue')
title_label.pack(side=tk.TOP, anchor='w', padx=(8, 4), pady=(12, 0))

# Subtítulo
subtitle_label = Label(frame_header, text="Tecnología Superior en Big Data", font=("Helvetica", 18), bg='lightblue')
subtitle_label.pack(side=tk.TOP, anchor='w', padx=(8, 4), pady=(0, 12))

# Crear un marco para la cámara y el logo
frame_camera = Frame(root)
frame_camera.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=5, pady=5)

# Cargar la imagen (ajusta la ruta a tu imagen)
image_path = r"C:\Users\ZENBOOK\OneDrive\Desktop\Proyecto Final\LOGO-RECTANGULAR_SIN-FONDO.png"  # Cambia esto a la ruta de tu logo
logo_image = Image.open(image_path)
logo_image = logo_image.resize((350, 200), Image.LANCZOS)  # Redimensionar la imagen si es necesario
logo_photo = ImageTk.PhotoImage(logo_image)

# Colocar la imagen debajo del subtítulo
logo_label = Label(frame_header, image=logo_photo, bg='white', borderwidth=0, highlightthickness=0)
logo_label.pack(side=tk.TOP, anchor='w', padx=(8, 4), pady=(0, 12))

# Crear una etiqueta para mostrar el video
label_video = Label(frame_camera)
label_video.pack(fill=tk.BOTH, expand=True)

# Inicializa la cámara
cap = cv2.VideoCapture(0)

# Configura la resolución de la cámara
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Verifica si la cámara se abrió correctamente
if not cap.isOpened():
    print("Error: No se pudo abrir la cámara.")
    root.destroy()
    exit()

# Configura el gráfico principal (histograma) más grande
fig_main, axs_main = plt.subplots(1, 1, figsize=(12, 8))
axs_main.set_title('Detección de Emociones (Histograma)', fontsize=20, fontweight='bold')
axs_main.set_xlabel('Emociones', fontsize=14)
axs_main.set_ylabel('Porcentaje', fontsize=14)
axs_main.set_ylim(0, 100)
axs_main.grid(True, linestyle='--', alpha=0.7)

# Configura los gráficos secundarios más pequeños
fig_sec, axs_sec = plt.subplots(1, 3, figsize=(16, 5))

# Colores vibrantes
colors = {
    'happy': '#FFEB3B',     # Amarillo brillante
    'angry': '#F44336',     # Rojo brillante
    'sad': '#2196F3',       # Azul brillante
    'surprised': '#FF5722', # Naranja brillante
    'neutral': '#9E9E9E'    # Gris neutro
}

# Función para actualizar los gráficos
def update_graphs(emotions):
    # Actualizar gráfico principal (Histograma)
    axs_main.clear()
    axs_main.bar(emotions.keys(), emotions.values(), color=[colors.get(e, '#E0E0E0') for e in emotions.keys()])
    axs_main.set_title('Detección de Emociones (Histograma)', fontsize=20, fontweight='bold')
    axs_main.set_xlabel('Emociones', fontsize=14)
    axs_main.set_ylabel('Porcentaje', fontsize=14)
    axs_main.set_ylim(0, 100)
    axs_main.grid(True, linestyle='--', alpha=0.7)

    # Actualizar gráficos secundarios
    axs_sec[0].clear()
    axs_sec[0].pie([emotions.get('happy', 0), 100 - emotions.get('happy', 0)],
                   labels=['Felicidad', 'Otros'],
                   autopct='%1.1f%%',
                   startangle=140,
                   colors=[colors['happy'], '#E0E0E0'])
    axs_sec[0].set_title('Detección de Felicidad', fontsize=14)

    axs_sec[1].clear()
    axs_sec[1].pie([emotions.get('angry', 0), 100 - emotions.get('angry', 0)],
                   labels=['Estrés', 'Otros'],
                   autopct='%1.1f%%',
                   startangle=140,
                   colors=[colors['angry'], '#E0E0E0'])
    axs_sec[1].set_title('Detección de Estrés', fontsize=14)

    axs_sec[2].clear()
    axs_sec[2].pie([emotions.get('sad', 0), 100 - emotions.get('sad', 0)],
                   labels=['Tristeza', 'Otros'],
                   autopct='%1.1f%%',
                   startangle=140,
                   colors=[colors['sad'], '#E0E0E0'])
    axs_sec[2].set_title('Detección de Tristeza', fontsize=14)

    canvas_main.draw()
    canvas_sec.draw()

# Función para analizar emociones en un hilo separado
def analyze_emotions(frame):
    global current_emotions
    small_frame = cv2.resize(frame, (320, 240))
    rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
    try:
        # Aumentar el tamaño del rostro detectado
        face_analysis = DeepFace.analyze(rgb_frame, actions=['emotion'], enforce_detection=False)
        if not face_analysis:
            return
        
        # Mejorar la precisión mediante la detección de múltiples caras
        emotions = {}
        for person in face_analysis:
            detected_emotions = person['emotion']
            for emotion, value in detected_emotions.items():
                if emotion not in emotions:
                    emotions[emotion] = 0
                emotions[emotion] += value
        
        # Normalizar los valores para la visualización
        total = sum(emotions.values())
        if total > 0:
            emotions = {e: (v / total) * 100 for e, v in emotions.items()}
        
        current_emotions = {k: v for k, v in emotions.items() if k in ['happy', 'angry', 'sad', 'surprised', 'neutral']}
        root.after(0, update_graphs, current_emotions)
    except Exception as e:
        print(f"Error en la detección de emociones: {e}")

# Función para actualizar el video
def update_video():
    ret, frame = cap.read()
    
    if not ret:
        print("Error: No se pudo capturar el fotograma.")
        root.destroy()
        return

    image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    photo = ImageTk.PhotoImage(image=image)
    
    label_video.config(image=photo)
    label_video.image = photo
    
    root.after(30, update_video)

# Función para analizar emociones periódicamente
def periodic_analysis():
    ret, frame = cap.read()
    if ret:
        threading.Thread(target=analyze_emotions, args=(frame,)).start()
    root.after(1000, periodic_analysis)

# Crear un marco para los gráficos secundarios (parte baja izquierda)
frame_graphs_sec = Frame(root)
frame_graphs_sec.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)

# Crear un marco para el gráfico principal (parte derecha)
frame_graphs_main = Frame(root)
frame_graphs_main.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)

# Configurar el canvas para el gráfico principal
canvas_main = FigureCanvasTkAgg(fig_main, master=frame_graphs_main)
canvas_main.draw()
canvas_main.get_tk_widget().pack(fill=tk.BOTH, expand=True)

# Configurar el canvas para los gráficos secundarios
canvas_sec = FigureCanvasTkAgg(fig_sec, master=frame_graphs_sec)
canvas_sec.draw()
canvas_sec.get_tk_widget().pack(fill=tk.BOTH, expand=True)

# Iniciar la actualización del video
update_video()

# Iniciar el análisis periódico de emociones
periodic_analysis()

# Ejecutar la interfaz gráfica
root.mainloop()

# Libera la cámara después de cerrar la ventana
cap.release()
cv2.destroyAllWindows()
